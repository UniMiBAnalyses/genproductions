      SUBROUTINE HELAS_CALLS_AMPB_1(P,NHEL,H,IC)
C     
C     Modules
C     
      USE POLYNOMIAL_CONSTANTS
C     
      IMPLICIT NONE
C     
C     CONSTANTS
C     
      INTEGER    NEXTERNAL
      PARAMETER (NEXTERNAL=6)
      INTEGER    NCOMB
      PARAMETER (NCOMB=96)
      INTEGER NBORNAMPS
      PARAMETER (NBORNAMPS=13)
      INTEGER    NLOOPS, NLOOPGROUPS, NCTAMPS
      PARAMETER (NLOOPS=129, NLOOPGROUPS=40, NCTAMPS=213)
      INTEGER    NLOOPAMPS
      PARAMETER (NLOOPAMPS=342)
      INTEGER    NWAVEFUNCS,NLOOPWAVEFUNCS
      PARAMETER (NWAVEFUNCS=41,NLOOPWAVEFUNCS=206)
      REAL*8     ZERO
      PARAMETER (ZERO=0D0)
      REAL*16     MP__ZERO
      PARAMETER (MP__ZERO=0.0E0_16)
C     These are constants related to the split orders
      INTEGER    NSO, NSQUAREDSO, NAMPSO
      PARAMETER (NSO=1, NSQUAREDSO=1, NAMPSO=2)
C     
C     ARGUMENTS
C     
      REAL*8 P(0:3,NEXTERNAL)
      INTEGER NHEL(NEXTERNAL), IC(NEXTERNAL)
      INTEGER H
C     
C     LOCAL VARIABLES
C     
      INTEGER I,J,K
      COMPLEX*16 COEFS(MAXLWFSIZE,0:VERTEXMAXCOEFS-1,MAXLWFSIZE)

      LOGICAL DUMMYFALSE
      DATA DUMMYFALSE/.FALSE./
C     
C     GLOBAL VARIABLES
C     
      INCLUDE 'coupl.inc'
      INCLUDE 'mp_coupl.inc'

      INTEGER HELOFFSET
      INTEGER GOODHEL(NCOMB)
      LOGICAL GOODAMP(NSQUAREDSO,NLOOPGROUPS)
      COMMON/FILTERS/GOODAMP,GOODHEL,HELOFFSET

      LOGICAL CHECKPHASE
      LOGICAL HELDOUBLECHECKED
      COMMON/INIT/CHECKPHASE, HELDOUBLECHECKED

      INTEGER SQSO_TARGET
      COMMON/SOCHOICE/SQSO_TARGET

      LOGICAL UVCT_REQ_SO_DONE,MP_UVCT_REQ_SO_DONE,CT_REQ_SO_DONE
     $ ,MP_CT_REQ_SO_DONE,LOOP_REQ_SO_DONE,MP_LOOP_REQ_SO_DONE
     $ ,CTCALL_REQ_SO_DONE,FILTER_SO
      COMMON/SO_REQS/UVCT_REQ_SO_DONE,MP_UVCT_REQ_SO_DONE
     $ ,CT_REQ_SO_DONE,MP_CT_REQ_SO_DONE,LOOP_REQ_SO_DONE
     $ ,MP_LOOP_REQ_SO_DONE,CTCALL_REQ_SO_DONE,FILTER_SO

      INTEGER I_SO
      COMMON/I_SO/I_SO
      INTEGER I_LIB
      COMMON/I_LIB/I_LIB

      COMPLEX*16 AMP(NBORNAMPS)
      COMMON/AMPS/AMP
      COMPLEX*16 W(20,NWAVEFUNCS)
      COMMON/W/W

      COMPLEX*16 WL(MAXLWFSIZE,0:LOOPMAXCOEFS-1,MAXLWFSIZE,
     $ -1:NLOOPWAVEFUNCS)
      COMPLEX*16 PL(0:3,-1:NLOOPWAVEFUNCS)
      COMMON/WL/WL,PL

      COMPLEX*16 AMPL(3,NCTAMPS)
      COMMON/AMPL/AMPL

C     
C     ----------
C     BEGIN CODE
C     ----------

C     The target squared split order contribution is already reached
C      if true.
      IF (FILTER_SO.AND.CT_REQ_SO_DONE) THEN
        GOTO 1001
      ENDIF

      CALL VXXXXX(P(0,1),ZERO,NHEL(1),-1*IC(1),W(1,1))
      CALL IXXXXX(P(0,2),ZERO,NHEL(2),+1*IC(2),W(1,2))
      CALL IXXXXX(P(0,3),MDL_MTA,NHEL(3),-1*IC(3),W(1,3))
      CALL OXXXXX(P(0,4),ZERO,NHEL(4),+1*IC(4),W(1,4))
      CALL VXXXXX(P(0,5),MDL_MW,NHEL(5),+1*IC(5),W(1,5))
      CALL OXXXXX(P(0,6),ZERO,NHEL(6),+1*IC(6),W(1,6))
      CALL FFV1_2(W(1,2),W(1,1),GC_5,ZERO,ZERO,W(1,7))
      CALL FFV2_3(W(1,3),W(1,4),GC_47,MDL_MW,MDL_WW,W(1,8))
      CALL FFV1P0_3(W(1,7),W(1,6),GC_2,ZERO,ZERO,W(1,9))
C     Amplitude(s) for born diagram with ID 1
      CALL VVV1_0(W(1,9),W(1,5),W(1,8),GC_25,AMP(1))
      CALL FFV2_5_3(W(1,7),W(1,6),GC_22,GC_23,MDL_MZ,MDL_WZ,W(1,10))
C     Amplitude(s) for born diagram with ID 2
      CALL VVV1_0(W(1,5),W(1,8),W(1,10),GC_7,AMP(2))
      CALL FFV2_1(W(1,6),W(1,5),GC_47,ZERO,ZERO,W(1,11))
C     Amplitude(s) for born diagram with ID 3
      CALL FFV2_0(W(1,7),W(1,11),W(1,8),GC_47,AMP(3))
      CALL FFV2_2(W(1,3),W(1,5),GC_47,ZERO,ZERO,W(1,12))
C     Amplitude(s) for born diagram with ID 4
      CALL FFV2_0(W(1,12),W(1,4),W(1,10),GC_28,AMP(4))
      CALL FFV2_1(W(1,4),W(1,5),GC_47,MDL_MTA,ZERO,W(1,13))
C     Amplitude(s) for born diagram with ID 5
      CALL FFV1_0(W(1,3),W(1,13),W(1,9),-GC_25,AMP(5))
C     Amplitude(s) for born diagram with ID 6
      CALL FFV2_4_0(W(1,3),W(1,13),W(1,10),-GC_22,GC_24,AMP(6))
      CALL FFV1_1(W(1,6),W(1,1),GC_5,ZERO,ZERO,W(1,14))
      CALL FFV1P0_3(W(1,2),W(1,14),GC_2,ZERO,ZERO,W(1,15))
C     Amplitude(s) for born diagram with ID 7
      CALL VVV1_0(W(1,15),W(1,5),W(1,8),GC_25,AMP(7))
      CALL FFV2_5_3(W(1,2),W(1,14),GC_22,GC_23,MDL_MZ,MDL_WZ,W(1,16))
C     Amplitude(s) for born diagram with ID 8
      CALL VVV1_0(W(1,5),W(1,8),W(1,16),GC_7,AMP(8))
      CALL FFV2_1(W(1,14),W(1,5),GC_47,ZERO,ZERO,W(1,17))
C     Amplitude(s) for born diagram with ID 9
      CALL FFV2_0(W(1,2),W(1,17),W(1,8),GC_47,AMP(9))
C     Amplitude(s) for born diagram with ID 10
      CALL FFV2_0(W(1,12),W(1,4),W(1,16),GC_28,AMP(10))
C     Amplitude(s) for born diagram with ID 11
      CALL FFV1_0(W(1,3),W(1,13),W(1,15),-GC_25,AMP(11))
C     Amplitude(s) for born diagram with ID 12
      CALL FFV2_4_0(W(1,3),W(1,13),W(1,16),-GC_22,GC_24,AMP(12))
      CALL FFV1_1(W(1,11),W(1,1),GC_5,ZERO,ZERO,W(1,18))
C     Amplitude(s) for born diagram with ID 13
      CALL FFV2_0(W(1,2),W(1,18),W(1,8),GC_47,AMP(13))
      CALL FFV2_2(W(1,7),W(1,8),GC_47,ZERO,ZERO,W(1,19))
C     Counter-term amplitude(s) for loop diagram number 14
      CALL R2_QQ_1_0(W(1,19),W(1,11),R2_QQQ,AMPL(1,1))
C     Counter-term amplitude(s) for loop diagram number 15
      CALL FFV2_0(W(1,7),W(1,11),W(1,8),R2_SXCW,AMPL(1,2))
C     Counter-term amplitude(s) for loop diagram number 16
      CALL FFV2_0(W(1,19),W(1,6),W(1,5),R2_SXCW,AMPL(1,3))
      CALL FFV2_2(W(1,2),W(1,8),GC_47,ZERO,ZERO,W(1,20))
C     Counter-term amplitude(s) for loop diagram number 18
      CALL R2_QQ_1_0(W(1,20),W(1,17),R2_QQQ,AMPL(1,4))
C     Counter-term amplitude(s) for loop diagram number 19
      CALL FFV2_0(W(1,2),W(1,17),W(1,8),R2_SXCW,AMPL(1,5))
C     Counter-term amplitude(s) for loop diagram number 20
      CALL FFV2_0(W(1,20),W(1,14),W(1,5),R2_SXCW,AMPL(1,6))
      CALL FFV1P0_3(W(1,2),W(1,6),GC_5,ZERO,ZERO,W(1,21))
      CALL VVV1_3(W(1,5),W(1,8),GC_7,MDL_MZ,MDL_WZ,W(1,22))
C     Counter-term amplitude(s) for loop diagram number 22
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,22),-R2_GGZUP,AMPL(1,7))
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,22),-R2_GGZUP,AMPL(1,8))
C     Counter-term amplitude(s) for loop diagram number 23
      CALL R2_GGVV_0(W(1,1),W(1,21),W(1,5),W(1,8),R2_GGWWCS,AMPL(1,9))
      CALL R2_GGVV_0(W(1,1),W(1,21),W(1,5),W(1,8),R2_GGWWCS,AMPL(1,10))
      CALL FFV2_3(W(1,12),W(1,4),GC_28,MDL_MZ,MDL_WZ,W(1,23))
C     Counter-term amplitude(s) for loop diagram number 27
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,23),-R2_GGZUP,AMPL(1,11))
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,23),-R2_GGZUP,AMPL(1,12))
      CALL FFV2_4_3(W(1,3),W(1,13),-GC_22,GC_24,MDL_MZ,MDL_WZ,W(1,24))
C     Counter-term amplitude(s) for loop diagram number 29
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,24),-R2_GGZUP,AMPL(1,13))
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,24),-R2_GGZUP,AMPL(1,14))
C     Counter-term amplitude(s) for loop diagram number 32
      CALL FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQQ_1EPS,AMPL(2,15))
      CALL FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQQ_1EPS,AMPL(2,16))
      CALL FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQQ_1EPS,AMPL(2,17))
      CALL FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQQ_1EPS,AMPL(2,18))
      CALL FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQB,AMPL(1,19))
      CALL FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQQ_1EPS,AMPL(2,20))
      CALL FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQT,AMPL(1,21))
      CALL FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQQ_1EPS,AMPL(2,22))
      CALL FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQG_1EPS,AMPL(2,23))
      CALL FFV1_0(W(1,20),W(1,11),W(1,1),R2_GQQ,AMPL(1,24))
C     Counter-term amplitude(s) for loop diagram number 38
      CALL R2_QQ_1_0(W(1,20),W(1,18),R2_QQQ,AMPL(1,25))
C     Counter-term amplitude(s) for loop diagram number 39
      CALL FFV2_0(W(1,2),W(1,18),W(1,8),R2_SXCW,AMPL(1,26))
      CALL FFV1_2(W(1,20),W(1,1),GC_5,ZERO,ZERO,W(1,25))
C     Counter-term amplitude(s) for loop diagram number 40
      CALL R2_QQ_1_0(W(1,25),W(1,11),R2_QQQ,AMPL(1,27))
C     Counter-term amplitude(s) for loop diagram number 46
      CALL FFV2_0(W(1,25),W(1,6),W(1,5),R2_SXCW,AMPL(1,28))
      CALL VVV1P0_1(W(1,5),W(1,8),GC_25,ZERO,ZERO,W(1,26))
C     Counter-term amplitude(s) for loop diagram number 50
      CALL FFV1_0(W(1,7),W(1,6),W(1,26),R2_UUA,AMPL(1,29))
      CALL FFV1_1(W(1,6),W(1,26),GC_2,ZERO,ZERO,W(1,27))
C     Counter-term amplitude(s) for loop diagram number 51
      CALL R2_QQ_1_0(W(1,7),W(1,27),R2_QQQ,AMPL(1,30))
C     Counter-term amplitude(s) for loop diagram number 52
      CALL FFV2_5_0(W(1,7),W(1,6),W(1,22),R2_UUZ_V2,R2_UUZ_V5,AMPL(1
     $ ,31))
      CALL FFV2_5_1(W(1,6),W(1,22),GC_22,GC_23,ZERO,ZERO,W(1,28))
C     Counter-term amplitude(s) for loop diagram number 53
      CALL R2_QQ_1_0(W(1,7),W(1,28),R2_QQQ,AMPL(1,32))
      CALL FFV2_1(W(1,11),W(1,8),GC_47,ZERO,ZERO,W(1,29))
C     Counter-term amplitude(s) for loop diagram number 54
      CALL R2_QQ_1_0(W(1,7),W(1,29),R2_QQQ,AMPL(1,33))
C     Counter-term amplitude(s) for loop diagram number 55
      CALL FFV2_5_0(W(1,7),W(1,6),W(1,23),R2_UUZ_V2,R2_UUZ_V5,AMPL(1
     $ ,34))
      CALL FFV2_5_1(W(1,6),W(1,23),GC_22,GC_23,ZERO,ZERO,W(1,30))
C     Counter-term amplitude(s) for loop diagram number 56
      CALL R2_QQ_1_0(W(1,7),W(1,30),R2_QQQ,AMPL(1,35))
      CALL FFV1P0_3(W(1,3),W(1,13),-GC_25,ZERO,ZERO,W(1,31))
C     Counter-term amplitude(s) for loop diagram number 57
      CALL FFV1_0(W(1,7),W(1,6),W(1,31),R2_UUA,AMPL(1,36))
      CALL FFV1_1(W(1,6),W(1,31),GC_2,ZERO,ZERO,W(1,32))
C     Counter-term amplitude(s) for loop diagram number 58
      CALL R2_QQ_1_0(W(1,7),W(1,32),R2_QQQ,AMPL(1,37))
C     Counter-term amplitude(s) for loop diagram number 59
      CALL FFV2_5_0(W(1,7),W(1,6),W(1,24),R2_UUZ_V2,R2_UUZ_V5,AMPL(1
     $ ,38))
      CALL FFV2_5_1(W(1,6),W(1,24),GC_22,GC_23,ZERO,ZERO,W(1,33))
C     Counter-term amplitude(s) for loop diagram number 60
      CALL R2_QQ_1_0(W(1,7),W(1,33),R2_QQQ,AMPL(1,39))
C     Counter-term amplitude(s) for loop diagram number 61
      CALL FFV1_0(W(1,2),W(1,14),W(1,26),R2_UUA,AMPL(1,40))
C     Counter-term amplitude(s) for loop diagram number 62
      CALL FFV2_5_0(W(1,2),W(1,14),W(1,22),R2_UUZ_V2,R2_UUZ_V5,AMPL(1
     $ ,41))
C     Counter-term amplitude(s) for loop diagram number 63
      CALL FFV2_5_0(W(1,2),W(1,14),W(1,23),R2_UUZ_V2,R2_UUZ_V5,AMPL(1
     $ ,42))
C     Counter-term amplitude(s) for loop diagram number 64
      CALL FFV1_0(W(1,2),W(1,14),W(1,31),R2_UUA,AMPL(1,43))
C     Counter-term amplitude(s) for loop diagram number 65
      CALL FFV2_5_0(W(1,2),W(1,14),W(1,24),R2_UUZ_V2,R2_UUZ_V5,AMPL(1
     $ ,44))
      CALL FFV2_2(W(1,20),W(1,5),GC_47,ZERO,ZERO,W(1,34))
C     Counter-term amplitude(s) for loop diagram number 66
      CALL R2_QQ_1_0(W(1,34),W(1,14),R2_QQQ,AMPL(1,45))
      CALL FFV1_2(W(1,2),W(1,26),GC_2,ZERO,ZERO,W(1,35))
C     Counter-term amplitude(s) for loop diagram number 67
      CALL R2_QQ_1_0(W(1,35),W(1,14),R2_QQQ,AMPL(1,46))
      CALL FFV2_5_2(W(1,2),W(1,22),GC_22,GC_23,ZERO,ZERO,W(1,36))
C     Counter-term amplitude(s) for loop diagram number 68
      CALL R2_QQ_1_0(W(1,36),W(1,14),R2_QQQ,AMPL(1,47))
      CALL FFV2_5_2(W(1,2),W(1,23),GC_22,GC_23,ZERO,ZERO,W(1,37))
C     Counter-term amplitude(s) for loop diagram number 69
      CALL R2_QQ_1_0(W(1,37),W(1,14),R2_QQQ,AMPL(1,48))
      CALL FFV1_2(W(1,2),W(1,31),GC_2,ZERO,ZERO,W(1,38))
C     Counter-term amplitude(s) for loop diagram number 70
      CALL R2_QQ_1_0(W(1,38),W(1,14),R2_QQQ,AMPL(1,49))
      CALL FFV2_5_2(W(1,2),W(1,24),GC_22,GC_23,ZERO,ZERO,W(1,39))
C     Counter-term amplitude(s) for loop diagram number 71
      CALL R2_QQ_1_0(W(1,39),W(1,14),R2_QQQ,AMPL(1,50))
C     Counter-term amplitude(s) for loop diagram number 72
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,22),R2_GGZUP,AMPL(1,51))
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,22),R2_GGZUP,AMPL(1,52))
C     Counter-term amplitude(s) for loop diagram number 74
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,23),R2_GGZUP,AMPL(1,53))
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,23),R2_GGZUP,AMPL(1,54))
C     Counter-term amplitude(s) for loop diagram number 76
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,24),R2_GGZUP,AMPL(1,55))
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,24),R2_GGZUP,AMPL(1,56))
C     Counter-term amplitude(s) for loop diagram number 79
      CALL FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQQ_1EPS,AMPL(2,57))
      CALL FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQQ_1EPS,AMPL(2,58))
      CALL FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQQ_1EPS,AMPL(2,59))
      CALL FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQQ_1EPS,AMPL(2,60))
      CALL FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQB,AMPL(1,61))
      CALL FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQQ_1EPS,AMPL(2,62))
      CALL FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQT,AMPL(1,63))
      CALL FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQQ_1EPS,AMPL(2,64))
      CALL FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQG_1EPS,AMPL(2,65))
      CALL FFV1_0(W(1,2),W(1,27),W(1,1),R2_GQQ,AMPL(1,66))
C     Counter-term amplitude(s) for loop diagram number 81
      CALL FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQQ_1EPS,AMPL(2,67))
      CALL FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQQ_1EPS,AMPL(2,68))
      CALL FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQQ_1EPS,AMPL(2,69))
      CALL FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQQ_1EPS,AMPL(2,70))
      CALL FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQB,AMPL(1,71))
      CALL FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQQ_1EPS,AMPL(2,72))
      CALL FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQT,AMPL(1,73))
      CALL FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQQ_1EPS,AMPL(2,74))
      CALL FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQG_1EPS,AMPL(2,75))
      CALL FFV1_0(W(1,2),W(1,28),W(1,1),R2_GQQ,AMPL(1,76))
C     Counter-term amplitude(s) for loop diagram number 82
      CALL FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQQ_1EPS,AMPL(2,77))
      CALL FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQQ_1EPS,AMPL(2,78))
      CALL FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQQ_1EPS,AMPL(2,79))
      CALL FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQQ_1EPS,AMPL(2,80))
      CALL FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQB,AMPL(1,81))
      CALL FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQQ_1EPS,AMPL(2,82))
      CALL FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQT,AMPL(1,83))
      CALL FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQQ_1EPS,AMPL(2,84))
      CALL FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQG_1EPS,AMPL(2,85))
      CALL FFV1_0(W(1,2),W(1,29),W(1,1),R2_GQQ,AMPL(1,86))
C     Counter-term amplitude(s) for loop diagram number 83
      CALL FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,87))
      CALL FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,88))
      CALL FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,89))
      CALL FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,90))
      CALL FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQB,AMPL(1,91))
      CALL FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,92))
      CALL FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQT,AMPL(1,93))
      CALL FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,94))
      CALL FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQG_1EPS,AMPL(2,95))
      CALL FFV1_0(W(1,34),W(1,6),W(1,1),R2_GQQ,AMPL(1,96))
C     Counter-term amplitude(s) for loop diagram number 84
      CALL FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,97))
      CALL FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,98))
      CALL FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,99))
      CALL FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,100))
      CALL FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQB,AMPL(1,101))
      CALL FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,102))
      CALL FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQT,AMPL(1,103))
      CALL FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,104))
      CALL FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQG_1EPS,AMPL(2,105))
      CALL FFV1_0(W(1,35),W(1,6),W(1,1),R2_GQQ,AMPL(1,106))
C     Counter-term amplitude(s) for loop diagram number 85
      CALL FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,107))
      CALL FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,108))
      CALL FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,109))
      CALL FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,110))
      CALL FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQB,AMPL(1,111))
      CALL FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,112))
      CALL FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQT,AMPL(1,113))
      CALL FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,114))
      CALL FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQG_1EPS,AMPL(2,115))
      CALL FFV1_0(W(1,36),W(1,6),W(1,1),R2_GQQ,AMPL(1,116))
C     Counter-term amplitude(s) for loop diagram number 89
      CALL FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQQ_1EPS,AMPL(2,117))
      CALL FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQQ_1EPS,AMPL(2,118))
      CALL FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQQ_1EPS,AMPL(2,119))
      CALL FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQQ_1EPS,AMPL(2,120))
      CALL FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQB,AMPL(1,121))
      CALL FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQQ_1EPS,AMPL(2,122))
      CALL FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQT,AMPL(1,123))
      CALL FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQQ_1EPS,AMPL(2,124))
      CALL FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQG_1EPS,AMPL(2,125))
      CALL FFV1_0(W(1,2),W(1,30),W(1,1),R2_GQQ,AMPL(1,126))
C     Counter-term amplitude(s) for loop diagram number 90
      CALL FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,127))
      CALL FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,128))
      CALL FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,129))
      CALL FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,130))
      CALL FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQB,AMPL(1,131))
      CALL FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,132))
      CALL FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQT,AMPL(1,133))
      CALL FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,134))
      CALL FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQG_1EPS,AMPL(2,135))
      CALL FFV1_0(W(1,37),W(1,6),W(1,1),R2_GQQ,AMPL(1,136))
C     Counter-term amplitude(s) for loop diagram number 93
      CALL FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQQ_1EPS,AMPL(2,137))
      CALL FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQQ_1EPS,AMPL(2,138))
      CALL FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQQ_1EPS,AMPL(2,139))
      CALL FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQQ_1EPS,AMPL(2,140))
      CALL FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQB,AMPL(1,141))
      CALL FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQQ_1EPS,AMPL(2,142))
      CALL FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQT,AMPL(1,143))
      CALL FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQQ_1EPS,AMPL(2,144))
      CALL FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQG_1EPS,AMPL(2,145))
      CALL FFV1_0(W(1,2),W(1,32),W(1,1),R2_GQQ,AMPL(1,146))
C     Counter-term amplitude(s) for loop diagram number 95
      CALL FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQQ_1EPS,AMPL(2,147))
      CALL FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQQ_1EPS,AMPL(2,148))
      CALL FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQQ_1EPS,AMPL(2,149))
      CALL FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQQ_1EPS,AMPL(2,150))
      CALL FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQB,AMPL(1,151))
      CALL FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQQ_1EPS,AMPL(2,152))
      CALL FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQT,AMPL(1,153))
      CALL FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQQ_1EPS,AMPL(2,154))
      CALL FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQG_1EPS,AMPL(2,155))
      CALL FFV1_0(W(1,2),W(1,33),W(1,1),R2_GQQ,AMPL(1,156))
C     Counter-term amplitude(s) for loop diagram number 96
      CALL FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,157))
      CALL FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,158))
      CALL FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,159))
      CALL FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,160))
      CALL FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQB,AMPL(1,161))
      CALL FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,162))
      CALL FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQT,AMPL(1,163))
      CALL FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,164))
      CALL FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQG_1EPS,AMPL(2,165))
      CALL FFV1_0(W(1,38),W(1,6),W(1,1),R2_GQQ,AMPL(1,166))
C     Counter-term amplitude(s) for loop diagram number 97
      CALL FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,167))
      CALL FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,168))
      CALL FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,169))
      CALL FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,170))
      CALL FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQB,AMPL(1,171))
      CALL FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,172))
      CALL FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQT,AMPL(1,173))
      CALL FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,174))
      CALL FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQG_1EPS,AMPL(2,175))
      CALL FFV1_0(W(1,39),W(1,6),W(1,1),R2_GQQ,AMPL(1,176))
      CALL VVS1_3(W(1,5),W(1,8),GC_31,MDL_MH,MDL_WH,W(1,40))
C     Counter-term amplitude(s) for loop diagram number 117
      CALL VVS1_0(W(1,1),W(1,21),W(1,40),R2_GGHB,AMPL(1,177))
C     Counter-term amplitude(s) for loop diagram number 118
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,22),-R2_GGZUP,AMPL(1,178))
C     Counter-term amplitude(s) for loop diagram number 119
      CALL R2_GGVV_0(W(1,1),W(1,21),W(1,5),W(1,8),R2_GGWWCS,AMPL(1,179)
     $ )
C     Counter-term amplitude(s) for loop diagram number 124
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,23),-R2_GGZUP,AMPL(1,180))
      CALL FFS1_3(W(1,3),W(1,13),GC_38,MDL_MH,MDL_WH,W(1,41))
C     Counter-term amplitude(s) for loop diagram number 126
      CALL VVS1_0(W(1,1),W(1,21),W(1,41),R2_GGHB,AMPL(1,181))
C     Counter-term amplitude(s) for loop diagram number 127
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,24),-R2_GGZUP,AMPL(1,182))
C     Counter-term amplitude(s) for loop diagram number 133
      CALL VVS1_0(W(1,1),W(1,21),W(1,40),R2_GGHT,AMPL(1,183))
C     Counter-term amplitude(s) for loop diagram number 134
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,22),R2_GGZUP,AMPL(1,184))
C     Counter-term amplitude(s) for loop diagram number 137
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,23),R2_GGZUP,AMPL(1,185))
C     Counter-term amplitude(s) for loop diagram number 139
      CALL VVS1_0(W(1,1),W(1,21),W(1,41),R2_GGHT,AMPL(1,186))
C     Counter-term amplitude(s) for loop diagram number 140
      CALL R2_GGZ_0(W(1,1),W(1,21),W(1,24),R2_GGZUP,AMPL(1,187))
C     At this point, all CT amps needed for (QCD=4), i.e. of split
C      order ID=1, are computed.
      IF(FILTER_SO.AND.SQSO_TARGET.EQ.1) GOTO 2000

      GOTO 1001
 2000 CONTINUE
      CT_REQ_SO_DONE=.TRUE.
 1001 CONTINUE
      END

