      SUBROUTINE MP_HELAS_CALLS_AMPB_1(P,NHEL,H,IC)
C     
      USE POLYNOMIAL_CONSTANTS
      IMPLICIT NONE
C     
C     CONSTANTS
C     
      INTEGER    NEXTERNAL
      PARAMETER (NEXTERNAL=6)
      INTEGER    NCOMB
      PARAMETER (NCOMB=96)

      INTEGER NBORNAMPS
      PARAMETER (NBORNAMPS=13)
      INTEGER    NLOOPS, NLOOPGROUPS, NCTAMPS
      PARAMETER (NLOOPS=125, NLOOPGROUPS=40, NCTAMPS=211)
      INTEGER    NLOOPAMPS
      PARAMETER (NLOOPAMPS=336)
      INTEGER    NWAVEFUNCS,NLOOPWAVEFUNCS
      PARAMETER (NWAVEFUNCS=40,NLOOPWAVEFUNCS=202)
      REAL*16     ZERO
      PARAMETER (ZERO=0.0E0_16)
      COMPLEX*32     IZERO
      PARAMETER (IZERO=CMPLX(0.0E0_16,0.0E0_16,KIND=16))
C     These are constants related to the split orders
      INTEGER    NSO, NSQUAREDSO, NAMPSO
      PARAMETER (NSO=1, NSQUAREDSO=1, NAMPSO=2)
C     
C     ARGUMENTS
C     
      REAL*16 P(0:3,NEXTERNAL)
      INTEGER NHEL(NEXTERNAL), IC(NEXTERNAL)
      INTEGER H
C     
C     LOCAL VARIABLES
C     
      INTEGER I,J,K
      COMPLEX*32 COEFS(MAXLWFSIZE,0:VERTEXMAXCOEFS-1,MAXLWFSIZE)
C     
C     GLOBAL VARIABLES
C     
      INCLUDE 'mp_coupl_same_name.inc'

      INTEGER GOODHEL(NCOMB)
      LOGICAL GOODAMP(NSQUAREDSO,NLOOPGROUPS)
      COMMON/FILTERS/GOODAMP,GOODHEL

      INTEGER SQSO_TARGET
      COMMON/SOCHOICE/SQSO_TARGET

      LOGICAL UVCT_REQ_SO_DONE,MP_UVCT_REQ_SO_DONE,CT_REQ_SO_DONE
     $ ,MP_CT_REQ_SO_DONE,LOOP_REQ_SO_DONE,MP_LOOP_REQ_SO_DONE
     $ ,CTCALL_REQ_SO_DONE,FILTER_SO
      COMMON/SO_REQS/UVCT_REQ_SO_DONE,MP_UVCT_REQ_SO_DONE
     $ ,CT_REQ_SO_DONE,MP_CT_REQ_SO_DONE,LOOP_REQ_SO_DONE
     $ ,MP_LOOP_REQ_SO_DONE,CTCALL_REQ_SO_DONE,FILTER_SO

      COMPLEX*32 AMP(NBORNAMPS)
      COMMON/MP_AMPS/AMP
      COMPLEX*32 W(20,NWAVEFUNCS)
      COMMON/MP_W/W

      COMPLEX*32 WL(MAXLWFSIZE,0:LOOPMAXCOEFS-1,MAXLWFSIZE,
     $ -1:NLOOPWAVEFUNCS)
      COMPLEX*32 PL(0:3,-1:NLOOPWAVEFUNCS)
      COMMON/MP_WL/WL,PL

      COMPLEX*32 AMPL(3,NCTAMPS)
      COMMON/MP_AMPL/AMPL

C     
C     ----------
C     BEGIN CODE
C     ----------

C     The target squared split order contribution is already reached
C      if true.
      IF (FILTER_SO.AND.MP_CT_REQ_SO_DONE) THEN
        GOTO 1001
      ENDIF

      CALL MP_VXXXXX(P(0,1),ZERO,NHEL(1),-1*IC(1),W(1,1))
      CALL MP_IXXXXX(P(0,2),ZERO,NHEL(2),+1*IC(2),W(1,2))
      CALL MP_IXXXXX(P(0,3),ZERO,NHEL(3),-1*IC(3),W(1,3))
      CALL MP_OXXXXX(P(0,4),ZERO,NHEL(4),+1*IC(4),W(1,4))
      CALL MP_VXXXXX(P(0,5),MDL_MW,NHEL(5),+1*IC(5),W(1,5))
      CALL MP_OXXXXX(P(0,6),ZERO,NHEL(6),+1*IC(6),W(1,6))
      CALL MP_FFV1_2(W(1,2),W(1,1),GC_5,ZERO,ZERO,W(1,7))
      CALL MP_FFV2_3(W(1,3),W(1,4),GC_47,MDL_MW,MDL_WW,W(1,8))
      CALL MP_FFV1P0_3(W(1,7),W(1,6),GC_2,ZERO,ZERO,W(1,9))
C     Amplitude(s) for born diagram with ID 1
      CALL MP_VVV1_0(W(1,9),W(1,5),W(1,8),GC_25,AMP(1))
      CALL MP_FFV2_5_3(W(1,7),W(1,6),GC_22,GC_23,MDL_MZ,MDL_WZ,W(1,10))
C     Amplitude(s) for born diagram with ID 2
      CALL MP_VVV1_0(W(1,5),W(1,8),W(1,10),GC_7,AMP(2))
      CALL MP_FFV2_1(W(1,6),W(1,5),GC_47,ZERO,ZERO,W(1,11))
C     Amplitude(s) for born diagram with ID 3
      CALL MP_FFV2_0(W(1,7),W(1,11),W(1,8),GC_47,AMP(3))
      CALL MP_FFV2_2(W(1,3),W(1,5),GC_47,ZERO,ZERO,W(1,12))
C     Amplitude(s) for born diagram with ID 4
      CALL MP_FFV2_0(W(1,12),W(1,4),W(1,10),GC_28,AMP(4))
      CALL MP_FFV2_1(W(1,4),W(1,5),GC_47,ZERO,ZERO,W(1,13))
C     Amplitude(s) for born diagram with ID 5
      CALL MP_FFV1_0(W(1,3),W(1,13),W(1,9),-GC_25,AMP(5))
C     Amplitude(s) for born diagram with ID 6
      CALL MP_FFV2_4_0(W(1,3),W(1,13),W(1,10),-GC_22,GC_24,AMP(6))
      CALL MP_FFV1_1(W(1,6),W(1,1),GC_5,ZERO,ZERO,W(1,14))
      CALL MP_FFV1P0_3(W(1,2),W(1,14),GC_2,ZERO,ZERO,W(1,15))
C     Amplitude(s) for born diagram with ID 7
      CALL MP_VVV1_0(W(1,15),W(1,5),W(1,8),GC_25,AMP(7))
      CALL MP_FFV2_5_3(W(1,2),W(1,14),GC_22,GC_23,MDL_MZ,MDL_WZ,W(1,16)
     $ )
C     Amplitude(s) for born diagram with ID 8
      CALL MP_VVV1_0(W(1,5),W(1,8),W(1,16),GC_7,AMP(8))
      CALL MP_FFV2_1(W(1,14),W(1,5),GC_47,ZERO,ZERO,W(1,17))
C     Amplitude(s) for born diagram with ID 9
      CALL MP_FFV2_0(W(1,2),W(1,17),W(1,8),GC_47,AMP(9))
C     Amplitude(s) for born diagram with ID 10
      CALL MP_FFV2_0(W(1,12),W(1,4),W(1,16),GC_28,AMP(10))
C     Amplitude(s) for born diagram with ID 11
      CALL MP_FFV1_0(W(1,3),W(1,13),W(1,15),-GC_25,AMP(11))
C     Amplitude(s) for born diagram with ID 12
      CALL MP_FFV2_4_0(W(1,3),W(1,13),W(1,16),-GC_22,GC_24,AMP(12))
      CALL MP_FFV1_1(W(1,11),W(1,1),GC_5,ZERO,ZERO,W(1,18))
C     Amplitude(s) for born diagram with ID 13
      CALL MP_FFV2_0(W(1,2),W(1,18),W(1,8),GC_47,AMP(13))
      CALL MP_FFV2_2(W(1,7),W(1,8),GC_47,ZERO,ZERO,W(1,19))
C     Counter-term amplitude(s) for loop diagram number 14
      CALL MP_R2_QQ_1_0(W(1,19),W(1,11),R2_QQQ,AMPL(1,1))
C     Counter-term amplitude(s) for loop diagram number 15
      CALL MP_FFV2_0(W(1,7),W(1,11),W(1,8),R2_SXCW,AMPL(1,2))
C     Counter-term amplitude(s) for loop diagram number 16
      CALL MP_FFV2_0(W(1,19),W(1,6),W(1,5),R2_SXCW,AMPL(1,3))
      CALL MP_FFV2_2(W(1,2),W(1,8),GC_47,ZERO,ZERO,W(1,20))
C     Counter-term amplitude(s) for loop diagram number 18
      CALL MP_R2_QQ_1_0(W(1,20),W(1,17),R2_QQQ,AMPL(1,4))
C     Counter-term amplitude(s) for loop diagram number 19
      CALL MP_FFV2_0(W(1,2),W(1,17),W(1,8),R2_SXCW,AMPL(1,5))
C     Counter-term amplitude(s) for loop diagram number 20
      CALL MP_FFV2_0(W(1,20),W(1,14),W(1,5),R2_SXCW,AMPL(1,6))
      CALL MP_FFV1P0_3(W(1,2),W(1,6),GC_5,ZERO,ZERO,W(1,21))
      CALL MP_VVV1_3(W(1,5),W(1,8),GC_7,MDL_MZ,MDL_WZ,W(1,22))
C     Counter-term amplitude(s) for loop diagram number 22
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,22),-R2_GGZUP,AMPL(1,7))
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,22),-R2_GGZUP,AMPL(1,8))
C     Counter-term amplitude(s) for loop diagram number 23
      CALL MP_R2_GGVV_0(W(1,1),W(1,21),W(1,5),W(1,8),R2_GGWWCS,AMPL(1
     $ ,9))
      CALL MP_R2_GGVV_0(W(1,1),W(1,21),W(1,5),W(1,8),R2_GGWWCS,AMPL(1
     $ ,10))
      CALL MP_FFV2_3(W(1,12),W(1,4),GC_28,MDL_MZ,MDL_WZ,W(1,23))
C     Counter-term amplitude(s) for loop diagram number 27
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,23),-R2_GGZUP,AMPL(1,11))
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,23),-R2_GGZUP,AMPL(1,12))
      CALL MP_FFV2_4_3(W(1,3),W(1,13),-GC_22,GC_24,MDL_MZ,MDL_WZ,W(1
     $ ,24))
C     Counter-term amplitude(s) for loop diagram number 29
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,24),-R2_GGZUP,AMPL(1,13))
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,24),-R2_GGZUP,AMPL(1,14))
C     Counter-term amplitude(s) for loop diagram number 32
      CALL MP_FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQQ_1EPS,AMPL(2,15))
      CALL MP_FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQQ_1EPS,AMPL(2,16))
      CALL MP_FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQQ_1EPS,AMPL(2,17))
      CALL MP_FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQQ_1EPS,AMPL(2,18))
      CALL MP_FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQB,AMPL(1,19))
      CALL MP_FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQQ_1EPS,AMPL(2,20))
      CALL MP_FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQT,AMPL(1,21))
      CALL MP_FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQQ_1EPS,AMPL(2,22))
      CALL MP_FFV1_0(W(1,20),W(1,11),W(1,1),UV_GQQG_1EPS,AMPL(2,23))
      CALL MP_FFV1_0(W(1,20),W(1,11),W(1,1),R2_GQQ,AMPL(1,24))
C     Counter-term amplitude(s) for loop diagram number 38
      CALL MP_R2_QQ_1_0(W(1,20),W(1,18),R2_QQQ,AMPL(1,25))
C     Counter-term amplitude(s) for loop diagram number 39
      CALL MP_FFV2_0(W(1,2),W(1,18),W(1,8),R2_SXCW,AMPL(1,26))
      CALL MP_FFV1_2(W(1,20),W(1,1),GC_5,ZERO,ZERO,W(1,25))
C     Counter-term amplitude(s) for loop diagram number 40
      CALL MP_R2_QQ_1_0(W(1,25),W(1,11),R2_QQQ,AMPL(1,27))
C     Counter-term amplitude(s) for loop diagram number 46
      CALL MP_FFV2_0(W(1,25),W(1,6),W(1,5),R2_SXCW,AMPL(1,28))
      CALL MP_VVV1P0_1(W(1,5),W(1,8),GC_25,ZERO,ZERO,W(1,26))
C     Counter-term amplitude(s) for loop diagram number 50
      CALL MP_FFV1_0(W(1,7),W(1,6),W(1,26),R2_UUA,AMPL(1,29))
      CALL MP_FFV1_1(W(1,6),W(1,26),GC_2,ZERO,ZERO,W(1,27))
C     Counter-term amplitude(s) for loop diagram number 51
      CALL MP_R2_QQ_1_0(W(1,7),W(1,27),R2_QQQ,AMPL(1,30))
C     Counter-term amplitude(s) for loop diagram number 52
      CALL MP_FFV2_5_0(W(1,7),W(1,6),W(1,22),R2_UUZ_V2,R2_UUZ_V5
     $ ,AMPL(1,31))
      CALL MP_FFV2_5_1(W(1,6),W(1,22),GC_22,GC_23,ZERO,ZERO,W(1,28))
C     Counter-term amplitude(s) for loop diagram number 53
      CALL MP_R2_QQ_1_0(W(1,7),W(1,28),R2_QQQ,AMPL(1,32))
      CALL MP_FFV2_1(W(1,11),W(1,8),GC_47,ZERO,ZERO,W(1,29))
C     Counter-term amplitude(s) for loop diagram number 54
      CALL MP_R2_QQ_1_0(W(1,7),W(1,29),R2_QQQ,AMPL(1,33))
C     Counter-term amplitude(s) for loop diagram number 55
      CALL MP_FFV2_5_0(W(1,7),W(1,6),W(1,23),R2_UUZ_V2,R2_UUZ_V5
     $ ,AMPL(1,34))
      CALL MP_FFV2_5_1(W(1,6),W(1,23),GC_22,GC_23,ZERO,ZERO,W(1,30))
C     Counter-term amplitude(s) for loop diagram number 56
      CALL MP_R2_QQ_1_0(W(1,7),W(1,30),R2_QQQ,AMPL(1,35))
      CALL MP_FFV1P0_3(W(1,3),W(1,13),-GC_25,ZERO,ZERO,W(1,31))
C     Counter-term amplitude(s) for loop diagram number 57
      CALL MP_FFV1_0(W(1,7),W(1,6),W(1,31),R2_UUA,AMPL(1,36))
      CALL MP_FFV1_1(W(1,6),W(1,31),GC_2,ZERO,ZERO,W(1,32))
C     Counter-term amplitude(s) for loop diagram number 58
      CALL MP_R2_QQ_1_0(W(1,7),W(1,32),R2_QQQ,AMPL(1,37))
C     Counter-term amplitude(s) for loop diagram number 59
      CALL MP_FFV2_5_0(W(1,7),W(1,6),W(1,24),R2_UUZ_V2,R2_UUZ_V5
     $ ,AMPL(1,38))
      CALL MP_FFV2_5_1(W(1,6),W(1,24),GC_22,GC_23,ZERO,ZERO,W(1,33))
C     Counter-term amplitude(s) for loop diagram number 60
      CALL MP_R2_QQ_1_0(W(1,7),W(1,33),R2_QQQ,AMPL(1,39))
C     Counter-term amplitude(s) for loop diagram number 61
      CALL MP_FFV1_0(W(1,2),W(1,14),W(1,26),R2_UUA,AMPL(1,40))
C     Counter-term amplitude(s) for loop diagram number 62
      CALL MP_FFV2_5_0(W(1,2),W(1,14),W(1,22),R2_UUZ_V2,R2_UUZ_V5
     $ ,AMPL(1,41))
C     Counter-term amplitude(s) for loop diagram number 63
      CALL MP_FFV2_5_0(W(1,2),W(1,14),W(1,23),R2_UUZ_V2,R2_UUZ_V5
     $ ,AMPL(1,42))
C     Counter-term amplitude(s) for loop diagram number 64
      CALL MP_FFV1_0(W(1,2),W(1,14),W(1,31),R2_UUA,AMPL(1,43))
C     Counter-term amplitude(s) for loop diagram number 65
      CALL MP_FFV2_5_0(W(1,2),W(1,14),W(1,24),R2_UUZ_V2,R2_UUZ_V5
     $ ,AMPL(1,44))
      CALL MP_FFV2_2(W(1,20),W(1,5),GC_47,ZERO,ZERO,W(1,34))
C     Counter-term amplitude(s) for loop diagram number 66
      CALL MP_R2_QQ_1_0(W(1,34),W(1,14),R2_QQQ,AMPL(1,45))
      CALL MP_FFV1_2(W(1,2),W(1,26),GC_2,ZERO,ZERO,W(1,35))
C     Counter-term amplitude(s) for loop diagram number 67
      CALL MP_R2_QQ_1_0(W(1,35),W(1,14),R2_QQQ,AMPL(1,46))
      CALL MP_FFV2_5_2(W(1,2),W(1,22),GC_22,GC_23,ZERO,ZERO,W(1,36))
C     Counter-term amplitude(s) for loop diagram number 68
      CALL MP_R2_QQ_1_0(W(1,36),W(1,14),R2_QQQ,AMPL(1,47))
      CALL MP_FFV2_5_2(W(1,2),W(1,23),GC_22,GC_23,ZERO,ZERO,W(1,37))
C     Counter-term amplitude(s) for loop diagram number 69
      CALL MP_R2_QQ_1_0(W(1,37),W(1,14),R2_QQQ,AMPL(1,48))
      CALL MP_FFV1_2(W(1,2),W(1,31),GC_2,ZERO,ZERO,W(1,38))
C     Counter-term amplitude(s) for loop diagram number 70
      CALL MP_R2_QQ_1_0(W(1,38),W(1,14),R2_QQQ,AMPL(1,49))
      CALL MP_FFV2_5_2(W(1,2),W(1,24),GC_22,GC_23,ZERO,ZERO,W(1,39))
C     Counter-term amplitude(s) for loop diagram number 71
      CALL MP_R2_QQ_1_0(W(1,39),W(1,14),R2_QQQ,AMPL(1,50))
C     Counter-term amplitude(s) for loop diagram number 72
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,22),R2_GGZUP,AMPL(1,51))
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,22),R2_GGZUP,AMPL(1,52))
C     Counter-term amplitude(s) for loop diagram number 74
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,23),R2_GGZUP,AMPL(1,53))
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,23),R2_GGZUP,AMPL(1,54))
C     Counter-term amplitude(s) for loop diagram number 76
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,24),R2_GGZUP,AMPL(1,55))
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,24),R2_GGZUP,AMPL(1,56))
C     Counter-term amplitude(s) for loop diagram number 79
      CALL MP_FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQQ_1EPS,AMPL(2,57))
      CALL MP_FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQQ_1EPS,AMPL(2,58))
      CALL MP_FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQQ_1EPS,AMPL(2,59))
      CALL MP_FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQQ_1EPS,AMPL(2,60))
      CALL MP_FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQB,AMPL(1,61))
      CALL MP_FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQQ_1EPS,AMPL(2,62))
      CALL MP_FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQT,AMPL(1,63))
      CALL MP_FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQQ_1EPS,AMPL(2,64))
      CALL MP_FFV1_0(W(1,2),W(1,27),W(1,1),UV_GQQG_1EPS,AMPL(2,65))
      CALL MP_FFV1_0(W(1,2),W(1,27),W(1,1),R2_GQQ,AMPL(1,66))
C     Counter-term amplitude(s) for loop diagram number 81
      CALL MP_FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQQ_1EPS,AMPL(2,67))
      CALL MP_FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQQ_1EPS,AMPL(2,68))
      CALL MP_FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQQ_1EPS,AMPL(2,69))
      CALL MP_FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQQ_1EPS,AMPL(2,70))
      CALL MP_FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQB,AMPL(1,71))
      CALL MP_FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQQ_1EPS,AMPL(2,72))
      CALL MP_FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQT,AMPL(1,73))
      CALL MP_FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQQ_1EPS,AMPL(2,74))
      CALL MP_FFV1_0(W(1,2),W(1,28),W(1,1),UV_GQQG_1EPS,AMPL(2,75))
      CALL MP_FFV1_0(W(1,2),W(1,28),W(1,1),R2_GQQ,AMPL(1,76))
C     Counter-term amplitude(s) for loop diagram number 82
      CALL MP_FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQQ_1EPS,AMPL(2,77))
      CALL MP_FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQQ_1EPS,AMPL(2,78))
      CALL MP_FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQQ_1EPS,AMPL(2,79))
      CALL MP_FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQQ_1EPS,AMPL(2,80))
      CALL MP_FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQB,AMPL(1,81))
      CALL MP_FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQQ_1EPS,AMPL(2,82))
      CALL MP_FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQT,AMPL(1,83))
      CALL MP_FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQQ_1EPS,AMPL(2,84))
      CALL MP_FFV1_0(W(1,2),W(1,29),W(1,1),UV_GQQG_1EPS,AMPL(2,85))
      CALL MP_FFV1_0(W(1,2),W(1,29),W(1,1),R2_GQQ,AMPL(1,86))
C     Counter-term amplitude(s) for loop diagram number 83
      CALL MP_FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,87))
      CALL MP_FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,88))
      CALL MP_FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,89))
      CALL MP_FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,90))
      CALL MP_FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQB,AMPL(1,91))
      CALL MP_FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,92))
      CALL MP_FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQT,AMPL(1,93))
      CALL MP_FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,94))
      CALL MP_FFV1_0(W(1,34),W(1,6),W(1,1),UV_GQQG_1EPS,AMPL(2,95))
      CALL MP_FFV1_0(W(1,34),W(1,6),W(1,1),R2_GQQ,AMPL(1,96))
C     Counter-term amplitude(s) for loop diagram number 84
      CALL MP_FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,97))
      CALL MP_FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,98))
      CALL MP_FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,99))
      CALL MP_FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,100))
      CALL MP_FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQB,AMPL(1,101))
      CALL MP_FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,102))
      CALL MP_FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQT,AMPL(1,103))
      CALL MP_FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,104))
      CALL MP_FFV1_0(W(1,35),W(1,6),W(1,1),UV_GQQG_1EPS,AMPL(2,105))
      CALL MP_FFV1_0(W(1,35),W(1,6),W(1,1),R2_GQQ,AMPL(1,106))
C     Counter-term amplitude(s) for loop diagram number 85
      CALL MP_FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,107))
      CALL MP_FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,108))
      CALL MP_FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,109))
      CALL MP_FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,110))
      CALL MP_FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQB,AMPL(1,111))
      CALL MP_FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,112))
      CALL MP_FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQT,AMPL(1,113))
      CALL MP_FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,114))
      CALL MP_FFV1_0(W(1,36),W(1,6),W(1,1),UV_GQQG_1EPS,AMPL(2,115))
      CALL MP_FFV1_0(W(1,36),W(1,6),W(1,1),R2_GQQ,AMPL(1,116))
C     Counter-term amplitude(s) for loop diagram number 89
      CALL MP_FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQQ_1EPS,AMPL(2,117))
      CALL MP_FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQQ_1EPS,AMPL(2,118))
      CALL MP_FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQQ_1EPS,AMPL(2,119))
      CALL MP_FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQQ_1EPS,AMPL(2,120))
      CALL MP_FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQB,AMPL(1,121))
      CALL MP_FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQQ_1EPS,AMPL(2,122))
      CALL MP_FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQT,AMPL(1,123))
      CALL MP_FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQQ_1EPS,AMPL(2,124))
      CALL MP_FFV1_0(W(1,2),W(1,30),W(1,1),UV_GQQG_1EPS,AMPL(2,125))
      CALL MP_FFV1_0(W(1,2),W(1,30),W(1,1),R2_GQQ,AMPL(1,126))
C     Counter-term amplitude(s) for loop diagram number 90
      CALL MP_FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,127))
      CALL MP_FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,128))
      CALL MP_FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,129))
      CALL MP_FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,130))
      CALL MP_FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQB,AMPL(1,131))
      CALL MP_FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,132))
      CALL MP_FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQT,AMPL(1,133))
      CALL MP_FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,134))
      CALL MP_FFV1_0(W(1,37),W(1,6),W(1,1),UV_GQQG_1EPS,AMPL(2,135))
      CALL MP_FFV1_0(W(1,37),W(1,6),W(1,1),R2_GQQ,AMPL(1,136))
C     Counter-term amplitude(s) for loop diagram number 93
      CALL MP_FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQQ_1EPS,AMPL(2,137))
      CALL MP_FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQQ_1EPS,AMPL(2,138))
      CALL MP_FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQQ_1EPS,AMPL(2,139))
      CALL MP_FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQQ_1EPS,AMPL(2,140))
      CALL MP_FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQB,AMPL(1,141))
      CALL MP_FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQQ_1EPS,AMPL(2,142))
      CALL MP_FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQT,AMPL(1,143))
      CALL MP_FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQQ_1EPS,AMPL(2,144))
      CALL MP_FFV1_0(W(1,2),W(1,32),W(1,1),UV_GQQG_1EPS,AMPL(2,145))
      CALL MP_FFV1_0(W(1,2),W(1,32),W(1,1),R2_GQQ,AMPL(1,146))
C     Counter-term amplitude(s) for loop diagram number 95
      CALL MP_FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQQ_1EPS,AMPL(2,147))
      CALL MP_FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQQ_1EPS,AMPL(2,148))
      CALL MP_FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQQ_1EPS,AMPL(2,149))
      CALL MP_FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQQ_1EPS,AMPL(2,150))
      CALL MP_FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQB,AMPL(1,151))
      CALL MP_FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQQ_1EPS,AMPL(2,152))
      CALL MP_FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQT,AMPL(1,153))
      CALL MP_FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQQ_1EPS,AMPL(2,154))
      CALL MP_FFV1_0(W(1,2),W(1,33),W(1,1),UV_GQQG_1EPS,AMPL(2,155))
      CALL MP_FFV1_0(W(1,2),W(1,33),W(1,1),R2_GQQ,AMPL(1,156))
C     Counter-term amplitude(s) for loop diagram number 96
      CALL MP_FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,157))
      CALL MP_FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,158))
      CALL MP_FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,159))
      CALL MP_FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,160))
      CALL MP_FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQB,AMPL(1,161))
      CALL MP_FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,162))
      CALL MP_FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQT,AMPL(1,163))
      CALL MP_FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,164))
      CALL MP_FFV1_0(W(1,38),W(1,6),W(1,1),UV_GQQG_1EPS,AMPL(2,165))
      CALL MP_FFV1_0(W(1,38),W(1,6),W(1,1),R2_GQQ,AMPL(1,166))
C     Counter-term amplitude(s) for loop diagram number 97
      CALL MP_FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,167))
      CALL MP_FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,168))
      CALL MP_FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,169))
      CALL MP_FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,170))
      CALL MP_FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQB,AMPL(1,171))
      CALL MP_FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,172))
      CALL MP_FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQT,AMPL(1,173))
      CALL MP_FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQQ_1EPS,AMPL(2,174))
      CALL MP_FFV1_0(W(1,39),W(1,6),W(1,1),UV_GQQG_1EPS,AMPL(2,175))
      CALL MP_FFV1_0(W(1,39),W(1,6),W(1,1),R2_GQQ,AMPL(1,176))
      CALL MP_VVS1_3(W(1,5),W(1,8),GC_31,MDL_MH,MDL_WH,W(1,40))
C     Counter-term amplitude(s) for loop diagram number 117
      CALL MP_VVS1_0(W(1,1),W(1,21),W(1,40),R2_GGHB,AMPL(1,177))
C     Counter-term amplitude(s) for loop diagram number 118
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,22),-R2_GGZUP,AMPL(1,178))
C     Counter-term amplitude(s) for loop diagram number 119
      CALL MP_R2_GGVV_0(W(1,1),W(1,21),W(1,5),W(1,8),R2_GGWWCS,AMPL(1
     $ ,179))
C     Counter-term amplitude(s) for loop diagram number 124
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,23),-R2_GGZUP,AMPL(1,180))
C     Counter-term amplitude(s) for loop diagram number 126
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,24),-R2_GGZUP,AMPL(1,181))
C     Counter-term amplitude(s) for loop diagram number 131
      CALL MP_VVS1_0(W(1,1),W(1,21),W(1,40),R2_GGHT,AMPL(1,182))
C     Counter-term amplitude(s) for loop diagram number 132
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,22),R2_GGZUP,AMPL(1,183))
C     Counter-term amplitude(s) for loop diagram number 135
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,23),R2_GGZUP,AMPL(1,184))
C     Counter-term amplitude(s) for loop diagram number 137
      CALL MP_R2_GGZ_0(W(1,1),W(1,21),W(1,24),R2_GGZUP,AMPL(1,185))
C     At this point, all CT amps needed for (QCD=4), i.e. of split
C      order ID=1, are computed.
      IF(FILTER_SO.AND.SQSO_TARGET.EQ.1) GOTO 2000

      GOTO 1001
 2000 CONTINUE
      MP_CT_REQ_SO_DONE=.TRUE.
 1001 CONTINUE
      END

